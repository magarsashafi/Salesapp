# KM Sales Manager — Simple & Commented

Projectichi kun bifa salphaa fi barachuuf mijataa ta'een qindaa'eera.

## Kutaa projectii
1. `data/model` — Odeeffannoo gurgurtaa
2. `data/local` — Room Database
3. `data/repository` — Database fi ViewModel wal qunnamsiisa
4. `ui/viewmodel` — State fi logic
5. `ui/screens` — Fuulota app
6. `ui/navigation` — Navigation
7. `ui/components` — UI components
8. `ui/theme` — Theme

## Shallaggii ijoo
- Total = Kiiloo × Gatii/kiiloo
- Haftee = Total - Kaffalame

## Halluu
- Kaffalame: cuquliisa
- Haftee: diimaa

Koodiin keessatti comment Afaan Oromoo dabalamee jira; faayila tokko tokkoon dubbisuun salphaa dha.


## Design
UI Theme fi style fakkii reference irratti hundaa'e: blue header, white rounded cards, green Paid, red Balance/Debt.
