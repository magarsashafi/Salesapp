# Qajeelfama Barnootaa

## 1. Model
`Sale` odeeffannoo gurgurtaa tokko bakka tokkootti kuusa.

## 2. DAO
DAO hojii database irratti raawwatamu ibsa:
- galchuu
- dubbisuu
- haqachuu

## 3. Repository
Repository bakka tokko irraa database operation qindeessa.

## 4. ViewModel
ViewModel data UI irraa adda baasa, akkasumas state eega.

## 5. Screen
Screen tokko hojii tokko irratti xiyyeeffata:
Dashboard, Add Sale, Sales, Reports, Settings/About.

## Fakkeenya comment
```kotlin
// Total gurgurtaa = kiiloo baay'ina × gatii kiiloo tokkoo
val total = quantityKg * pricePerKg

// Haftee = total irraa maallaqa kaffalame hir'isu
val balance = total - paidAmount
```
