# KM Sales Manager — Design Reference

UI'n fakkii reference irratti hundaa'e.

- Primary Blue: #0759D9
- Background: #F5F8FC
- Surface/Card: White
- Kaffale: green (#16A34A)
- Haftee: red (#DC2626)
- Warning/clock: orange
- Secondary accent: purple
- Card corners: 16dp
- Large cards: 22dp
- Button corners: rounded
- Navigation: bottom navigation
- Main action: Extended FAB "Gurgurtaa Haaraa"
- Typography: mata-duree bold, body ifa, gatiiwwan guddaa

## Qajeelfama
Screen haaraa yoo dabaltu:
1. `MaterialTheme.colorScheme.primary` fayyadami.
2. Card keessatti `RoundedCornerShape(16.dp)` fayyadami.
3. Kaffalameef `KMPaidGreen`/`KMPaidSoft`.
4. Hafteef `KMDebtRed`/`KMDebtSoft`.
5. Halluu hard-code hedduu screen keessatti hin kaa'in; `ui/theme/Theme.kt` irraa fayyadami.
