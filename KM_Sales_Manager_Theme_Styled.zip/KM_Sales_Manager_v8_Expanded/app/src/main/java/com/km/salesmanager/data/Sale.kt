// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "sales")
data class Sale(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: String,
    val salesLocation: String,
    val customerName: String,
    val kilos: Double,
    val pricePerKilo: Double,
    val commissionRate: Double = 3.0,
    val paymentStatus: String = PAYMENT_PAID
) {
    val total: Double get() = kilos * pricePerKilo
    val commission: Double get() = total * commissionRate / 100.0
    val outstanding: Double get() = if (paymentStatus == PAYMENT_DEBT) total else 0.0

    companion object {
        const val PAYMENT_PAID = "Kaffale"
        const val PAYMENT_DEBT = "Salaafa"
    }
}
