// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable fun SettingsScreen(onClear:()->Unit,onAbout:()->Unit){
    var confirm by remember{mutableStateOf(false)}
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){
        Text("Qindaa'ina",style=MaterialTheme.typography.headlineMedium)
        OutlinedButton(onClick={confirm=true},Modifier.fillMaxWidth()){Text("Galmee hunda haqii")}
        OutlinedButton(onClick=onAbout,Modifier.fillMaxWidth()){Text("Waa'ee app kanaa")}
        Text("KM Sales Manager • v2.0",color=MaterialTheme.colorScheme.onSurfaceVariant)
        if(confirm)AlertDialog(onDismissRequest={confirm=false},title={Text("Mirkanneessi")},text={Text("Galmee gurgurtaa hunda haqxuuf mirkaneessi.")},confirmButton={TextButton(onClick={onClear();confirm=false}){Text("Haqi")}},dismissButton={TextButton(onClick={confirm=false}){Text("Dhiisi")}})
    }
}
@Composable fun AboutScreen(onBack:()->Unit){
    Column(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Waa'ee KM Sales Manager",style=MaterialTheme.typography.headlineMedium);Text("App kun gurgurtaa, kiiloo, gatii, kaffaltii, haftee fi commission to'achuuf qophaa'e.");Text("Data Room Database keessatti bilbila irratti offline kuufama.");Button(onClick=onBack){Text("Deebi'i")}}
}
