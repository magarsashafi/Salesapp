// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.km.salesmanager.data.Sale
import com.km.salesmanager.ui.components.SaleCard
import com.km.salesmanager.ui.components.StatCard
import com.km.salesmanager.ui.components.money

@Composable fun SalesScreen(sales:List<Sale>,onDelete:(Sale)->Unit,onEdit:(Sale)->Unit) {
    var q by remember{mutableStateOf("")}; var paidOnly by remember{mutableStateOf(false)}; var debtOnly by remember{mutableStateOf(false)}; var filters by remember{mutableStateOf(false)}
    val list=sales.filter{
        (q.isBlank()||it.customerName.contains(q,true)||it.salesLocation.contains(q,true)||it.date.contains(q,true)) &&
        (!paidOnly||it.paymentStatus==Sale.PAYMENT_PAID) && (!debtOnly||it.paymentStatus==Sale.PAYMENT_DEBT)
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth()){Text("Galmee Gurgurtaa",style=MaterialTheme.typography.headlineMedium,modifier=Modifier.weight(1f));IconButton(onClick={filters=!filters}){Icon(Icons.Default.FilterList,null)}}
        OutlinedTextField(q,{q=it},Modifier.fillMaxWidth(),singleLine=true,label={Text("Maqaa, iddoo ykn guyyaa barbaadi")},leadingIcon={Icon(Icons.Default.Search,null)})
        if(filters) Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(6.dp)){FilterChip(paidOnly,{paidOnly=it; if(it) debtOnly=false},{Text("Kaffale")});FilterChip(debtOnly,{debtOnly=it; if(it) paidOnly=false},{Text("Haftee")});TextButton(onClick={q="";paidOnly=false;debtOnly=false}){Text("Reset")}}
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){StatCard("Kiiloo","${money(list.sumOf{it.kilos})} kg",Modifier.weight(1f));StatCard("Waliigala",money(list.sumOf{it.total}),Modifier.weight(1f))}
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(list,key={it.id}){SaleCard(it,onDelete={onDelete(it)})}}
    }
}
