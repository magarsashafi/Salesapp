// KM SALES MANAGER - Theme
// Bifti fi halluun kun fakkii reference irratti hundaa'e:
// blue app-bar, white cards, rounded corners, green paid, red debt.

package com.km.salesmanager.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Halluuwwan ijoo app: blue akka fakkii reference.
val KMBlue = Color(0xFF0759D9)
val KMBlueDark = Color(0xFF0645A8)
val KMBlueSoft = Color(0xFFEAF2FF)
val KMPaidGreen = Color(0xFF16A34A)
val KMPaidSoft = Color(0xFFE7F8ED)
val KMDebtRed = Color(0xFFDC2626)
val KMDebtSoft = Color(0xFFFFECEC)
val KMOrange = Color(0xFFF59E0B)
val KMOrangeSoft = Color(0xFFFFF2D8)
val KMPurple = Color(0xFF7C3AED)
val KMBackground = Color(0xFFF5F8FC)
val KMText = Color(0xFF16345C)
val KMSubText = Color(0xFF66758A)
val KMBorder = Color(0xFFDCE5F0)

private val LightColors = lightColorScheme(
    primary = KMBlue,
    onPrimary = Color.White,
    primaryContainer = KMBlueSoft,
    onPrimaryContainer = KMBlueDark,
    secondary = KMBlueDark,
    background = KMBackground,
    surface = Color.White,
    onBackground = KMText,
    onSurface = KMText,
    onSurfaceVariant = KMSubText,
    outline = KMBorder,
    error = KMDebtRed,
    errorContainer = KMDebtSoft,
    onErrorContainer = KMDebtRed
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF77A8FF),
    secondary = Color(0xFF9CBFFF),
    background = Color(0xFF0B1220),
    surface = Color(0xFF121C2D),
    onBackground = Color(0xFFE8EEF8),
    onSurface = Color(0xFFE8EEF8),
    onSurfaceVariant = Color(0xFFB8C4D6),
    error = Color(0xFFFF8A8A)
)

private val KMShapes = Shapes(
    extraSmall = androidx.compose.foundation.shape.RoundedCornerShape(8.sp),
    small = androidx.compose.foundation.shape.RoundedCornerShape(12.sp),
    medium = androidx.compose.foundation.shape.RoundedCornerShape(16.sp),
    large = androidx.compose.foundation.shape.RoundedCornerShape(22.sp),
    extraLarge = androidx.compose.foundation.shape.RoundedCornerShape(28.sp)
)

private val KMTypography = Typography(
    headlineMedium = TextStyle(fontSize = 24.sp, fontWeight = FontWeight.Bold, lineHeight = 30.sp),
    titleLarge = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 15.sp, lineHeight = 22.sp),
    bodyMedium = TextStyle(fontSize = 14.sp, lineHeight = 20.sp),
    labelLarge = TextStyle(fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
)

@Composable
fun KMSalesTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // Fakkii reference ifa (light) irratti xiyyeeffata; dark mode illee ni deggara.
    val colors = if (darkTheme) DarkColors else LightColors

    MaterialTheme(
        colorScheme = colors,
        typography = KMTypography,
        shapes = KMShapes,
        content = content
    )
}
