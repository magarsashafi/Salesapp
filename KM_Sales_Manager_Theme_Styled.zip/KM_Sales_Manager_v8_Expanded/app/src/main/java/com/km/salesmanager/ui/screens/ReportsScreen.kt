// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.km.salesmanager.data.Sale
import com.km.salesmanager.ui.components.StatCard
import com.km.salesmanager.ui.components.money
import java.text.SimpleDateFormat
import java.util.*

@Composable fun ReportsScreen(sales:List<Sale>) {
    var period by remember{mutableStateOf("Guyyaa")};var date by remember{mutableStateOf(SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date()))}
    val filtered=when(period){
        "Guyyaa"->sales.filter{it.date==date}
        "Ji'a"->sales.filter{it.date.startsWith(date.take(7))}
        else->{
            val selected=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(date)?:Date();val cal=Calendar.getInstance();cal.time=selected;cal.set(Calendar.DAY_OF_WEEK,cal.firstDayOfWeek);val start=cal.time;cal.add(Calendar.DAY_OF_YEAR,6);val end=cal.time
            sales.filter{val d=SimpleDateFormat("yyyy-MM-dd",Locale.US).parse(it.date)?:Date();d>=start&&d<=end}
        }
    }
    val total=filtered.sumOf{it.total};val paid=filtered.filter{it.paymentStatus==Sale.PAYMENT_PAID}.sumOf{it.total};val debt=filtered.filter{it.paymentStatus==Sale.PAYMENT_DEBT}.sumOf{it.total};val kg=filtered.sumOf{it.kilos};val commission=filtered.sumOf{it.commission}
    Column(Modifier.fillMaxSize().padding(18.dp)) {
        Text("Gabaasa",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        Text("Guyyaa, torban fi ji'a keessatti galii fi haftee.",color=MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(6.dp)){listOf("Guyyaa","Torban","Ji'a").forEach{FilterChip(period==it,{period=it},{Text(it)})}}
        OutlinedTextField(date,{date=it},Modifier.fillMaxWidth(),label={Text("Guyyaa filannoo (YYYY-MM-DD)")},singleLine=true)
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){StatCard("Kiiloo","${money(kg)} kg",Modifier.weight(1f));StatCard("Galii",money(total),Modifier.weight(1f))}
        StatCard("Kaffalame",money(paid),Modifier.fillMaxWidth().padding(top=8.dp))
        PaidDebtSection("Kaffalame",filtered.filter{it.paymentStatus==Sale.PAYMENT_PAID},false)
        StatCard("Haftee / Salaafa",money(debt),Modifier.fillMaxWidth().padding(top=8.dp))
        PaidDebtSection("Haftee / Salaafa",filtered.filter{it.paymentStatus==Sale.PAYMENT_DEBT},true)
        StatCard("Commission",money(commission),Modifier.fillMaxWidth().padding(top=8.dp))
    }
}
@Composable private fun PaidDebtSection(title:String,people:List<Sale>,debt:Boolean){
    Card(Modifier.fillMaxWidth().padding(top=8.dp)){Column(Modifier.padding(14.dp)){Text(title,fontWeight=FontWeight.Bold,color=if(debt)MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary);people.forEach{Row(Modifier.fillMaxWidth().padding(vertical=6.dp)){Text("${it.customerName} • ${it.date}",Modifier.weight(1f));Text(money(it.total),fontWeight=FontWeight.Bold,color=if(debt)MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary)}};if(people.isEmpty())Text("Namni hin jiru",color=MaterialTheme.colorScheme.onSurfaceVariant)}}
}
