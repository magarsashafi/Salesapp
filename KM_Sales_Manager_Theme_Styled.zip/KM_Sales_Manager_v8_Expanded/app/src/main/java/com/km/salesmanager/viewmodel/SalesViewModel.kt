// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.km.salesmanager.data.AppDatabase
import com.km.salesmanager.data.Sale
import com.km.salesmanager.data.SalesRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class SalesViewModel(app: Application) : AndroidViewModel(app) {
    private val migration = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL("ALTER TABLE sales ADD COLUMN salesLocation TEXT NOT NULL DEFAULT ''")
            db.execSQL("ALTER TABLE sales ADD COLUMN paymentStatus TEXT NOT NULL DEFAULT 'Kaffale'")
        }
    }

    private val db = Room.databaseBuilder(app, AppDatabase::class.java, "km_sales.db")
        .addMigrations(migration)
        .fallbackToDestructiveMigration()
        .build()
    private val repo = SalesRepository(db.saleDao())

    val sales = repo.sales.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun add(date:String, location:String, name:String, kilos:Double, price:Double, rate:Double, payment:String) =
        viewModelScope.launch { repo.add(Sale(date=date, salesLocation=location, customerName=name, kilos=kilos, pricePerKilo=price, commissionRate=rate, paymentStatus=payment)) }

    fun update(sale: Sale) = viewModelScope.launch { repo.update(sale) }
    fun delete(sale: Sale) = viewModelScope.launch { repo.delete(sale) }
    fun clearAll() = viewModelScope.launch { repo.deleteAll() }
}
