// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager.ui

object Routes {
    const val DASHBOARD = "dashboard"
    const val SALES = "sales"
    const val ADD = "add"
    const val REPORTS = "reports"
    const val SETTINGS = "settings"
    const val ABOUT = "about"
}
