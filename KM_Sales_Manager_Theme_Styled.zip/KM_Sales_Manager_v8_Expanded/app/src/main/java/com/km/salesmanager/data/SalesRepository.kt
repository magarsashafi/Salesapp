// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager.data

class SalesRepository(private val dao: SaleDao) {
    val sales = dao.observeAll()
    suspend fun add(sale: Sale) = dao.insert(sale)
    suspend fun update(sale: Sale) = dao.update(sale)
    suspend fun delete(sale: Sale) = dao.delete(sale)
    suspend fun deleteAll() = dao.deleteAll()
}
