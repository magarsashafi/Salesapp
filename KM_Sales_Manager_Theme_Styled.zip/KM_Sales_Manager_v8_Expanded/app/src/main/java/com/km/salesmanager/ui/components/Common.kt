// KM SALES MANAGER - Common UI Components
// Componentoonni kun screen adda addaa keessatti irra deddeebi'anii fayyadamu.

package com.km.salesmanager.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Print
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.km.salesmanager.data.Sale
import com.km.salesmanager.ui.theme.*
import java.text.NumberFormat
import java.util.Locale

private val nf = NumberFormat.getNumberInstance(Locale.US).apply { maximumFractionDigits = 2 }

fun money(v: Double) = nf.format(v)

@Composable
fun StatCard(
    title: String,
    value: String,
    modifier: Modifier = Modifier,
    icon: @Composable (() -> Unit)? = null,
    accent: androidx.compose.ui.graphics.Color = KMBlue
) {
    // Card xiqqaan fakkii reference keessaa: maqaa, gatii fi icon.
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(7.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (icon != null) {
                    Box(
                        Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(accent.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) { icon() }
                    Spacer(Modifier.width(8.dp))
                }
                Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Text(
                value,
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun StatusPill(isPaid: Boolean) {
    // Kaffale = cuquliisa; Haftee = diimaa, akkuma fakkii reference.
    Surface(
        color = if (isPaid) KMPaidSoft else KMDebtSoft,
        shape = RoundedCornerShape(50)
    ) {
        Text(
            if (isPaid) "Kaffale" else "Haftee",
            color = if (isPaid) KMPaidGreen else KMDebtRed,
            style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
        )
    }
}

@Composable
fun SaleCard(
    sale: Sale,
    onDelete: (() -> Unit)? = null,
    onPrint: (() -> Unit)? = null
) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Avatar qubee maqaa namaa keessaa.
            val initial = sale.customerName.trim().firstOrNull()?.uppercase() ?: "?"
            Surface(
                Modifier.size(42.dp),
                shape = RoundedCornerShape(50),
                color = if (sale.paymentStatus == Sale.PAYMENT_PAID) KMBlue else KMPurple
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(initial, color = androidx.compose.ui.graphics.Color.White, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.width(12.dp))

            Column(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Text(
                    sale.customerName.ifBlank { "Maqaa hin galmoofne" },
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "${money(sale.kilos)} kg • ${money(sale.total)} ETB",
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    "${sale.salesLocation} • ${sale.date}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Column(horizontalAlignment = Alignment.End) {
                StatusPill(sale.paymentStatus == Sale.PAYMENT_PAID)
                Spacer(Modifier.height(5.dp))
                if (onDelete != null || onPrint != null) {
                    Row {
                        if (onPrint != null) IconButton(onClick = onPrint) {
                            Icon(Icons.Default.Print, "Maxxansi")
                        }
                        if (onDelete != null) IconButton(onClick = onDelete) {
                            Icon(Icons.Default.Delete, "Haqi")
                        }
                    }
                }
            }
        }
    }
}
