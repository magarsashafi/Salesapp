// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.km.salesmanager.data.Sale
import com.km.salesmanager.ui.components.SaleCard
import com.km.salesmanager.ui.components.StatCard
import com.km.salesmanager.ui.components.money

@Composable fun DashboardScreen(sales:List<Sale>,onAdd:()->Unit) {
    val kilos=sales.sumOf{it.kilos}; val total=sales.sumOf{it.total}; val paid=sales.filter{it.paymentStatus==Sale.PAYMENT_PAID}.sumOf{it.total}; val debt=sales.filter{it.paymentStatus==Sale.PAYMENT_DEBT}.sumOf{it.total}
    LazyColumn(Modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
        item{Text("KM Sales Manager",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold);Text("Gurgurtaa, galii fi haftee kee to'adhu.",color=MaterialTheme.colorScheme.onSurfaceVariant)}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){StatCard("Kiiloo","${money(kilos)} kg",Modifier.weight(1f));StatCard("Galii",money(total),Modifier.weight(1f))}}
        item{Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){StatCard("Kaffalame",money(paid),Modifier.weight(1f));StatCard("Haftee",money(debt),Modifier.weight(1f))}}
        item{Button(onClick=onAdd,Modifier.fillMaxWidth()){Icon(Icons.Default.Add,null);Spacer(Modifier.width(8.dp));Text("Gurgurtaa haaraa")}}
        item{Text("Galmee dhiyoo",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}
        items(sales.take(8),key={it.id}){SaleCard(it)}
        if(sales.isEmpty()) item{Text("Ammaaf galmeen hin jiru.",Modifier.padding(30.dp))}
    }
}
