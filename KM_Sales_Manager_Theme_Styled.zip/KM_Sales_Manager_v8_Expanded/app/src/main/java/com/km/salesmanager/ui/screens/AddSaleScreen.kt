// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.km.salesmanager.data.Sale
import com.km.salesmanager.ui.components.money
import java.text.SimpleDateFormat
import java.util.*

@Composable fun AddSaleScreen(onBack:()->Unit,onSave:(String,String,String,Double,Double,Double,String)->Unit) {
    var date by remember{mutableStateOf(SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date()))};var loc by remember{mutableStateOf("")};var name by remember{mutableStateOf("")};var kg by remember{mutableStateOf("")};var price by remember{mutableStateOf("")};var rate by remember{mutableStateOf("3")};var pay by remember{mutableStateOf(Sale.PAYMENT_PAID)}
    val kilos=kg.toDoubleOrNull()?:0.0;val p=price.toDoubleOrNull()?:0.0;val total=kilos*p
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(18.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
        Text("Gurgurtaa Haaraa",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
        OutlinedTextField(date,{date=it},Modifier.fillMaxWidth(),label={Text("Guyyaa (YYYY-MM-DD)")},singleLine=true)
        OutlinedTextField(loc,{loc=it},Modifier.fillMaxWidth(),label={Text("Iddoo Gurgurtaa")},singleLine=true)
        OutlinedTextField(name,{name=it},Modifier.fillMaxWidth(),label={Text("Maqaa")},singleLine=true)
        OutlinedTextField(kg,{kg=it},Modifier.fillMaxWidth(),label={Text("Kiilo")},singleLine=true)
        OutlinedTextField(price,{price=it},Modifier.fillMaxWidth(),label={Text("Gatii / kiiloo")},singleLine=true)
        OutlinedTextField(rate,{rate=it},Modifier.fillMaxWidth(),label={Text("Commission %")},singleLine=true)
        Text("Haala Kaffaltii",fontWeight=FontWeight.SemiBold)
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){FilterChip(pay==Sale.PAYMENT_PAID,{pay=Sale.PAYMENT_PAID},{Text("Kaffale")});FilterChip(pay==Sale.PAYMENT_DEBT,{pay=Sale.PAYMENT_DEBT},{Text("Salaafa / Haftee")})}
        Card(Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Waliigala: ${money(total)}",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);Text(if(pay==Sale.PAYMENT_PAID)"Kaffale: ${money(total)}" else "Haftee: ${money(total)}",color=if(pay==Sale.PAYMENT_PAID)MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error,fontWeight=FontWeight.Bold)}}
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick=onBack,Modifier.weight(1f)){Text("Dhiisi")};Button(enabled=loc.isNotBlank()&&name.isNotBlank()&&kilos>0&&p>=0,onClick={onSave(date,loc,name,kilos,p,rate.toDoubleOrNull()?:3.0,pay)},Modifier.weight(1f)){Text("Kuusi")}}
    }
}
