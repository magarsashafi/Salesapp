// KM SALES MANAGER - Main App Shell
// Top AppBar fi Bottom Navigation bifa fakkii reference irratti.

package com.km.salesmanager.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.BarChart
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.*
import com.km.salesmanager.ui.screens.*
import com.km.salesmanager.viewmodel.SalesViewModel

@Composable
fun KMSalesApp(vm: SalesViewModel = viewModel()) {
    val nav = rememberNavController()
    val sales by vm.sales.collectAsStateWithLifecycle()

    // Navigation gadii keessatti fuulota ijoo afur.
    val items = listOf(
        Routes.DASHBOARD to Pair("Mana", Icons.Default.Home),
        Routes.SALES to Pair("Gurgurtaa", Icons.Default.List),
        Routes.REPORTS to Pair("Gabaasa", Icons.Default.BarChart),
        Routes.SETTINGS to Pair("Qindaa'ina", Icons.Default.Settings)
    )

    Scaffold(
        // Button cuquliisaa "Gurgurtaa Haaraa" fakkii keessatti mul'atu.
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { nav.navigate(Routes.ADD) },
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Gurgurtaa Haaraa") }
            )
        },
        bottomBar = {
            NavigationBar {
                items.forEach { (route, item) ->
                    NavigationBarItem(
                        selected = nav.currentBackStackEntryAsState().value?.destination?.route == route,
                        onClick = {
                            nav.navigate(route) {
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.second, contentDescription = null) },
                        label = { Text(item.first) }
                    )
                }
            }
        }
    ) { pad ->
        NavHost(
            navController = nav,
            startDestination = Routes.DASHBOARD,
            modifier = Modifier.padding(pad)
        ) {
            composable(Routes.DASHBOARD) { DashboardScreen(sales) { nav.navigate(Routes.ADD) } }
            composable(Routes.SALES) { SalesScreen(sales, onDelete = vm::delete, onEdit = {}) }
            composable(Routes.ADD) {
                AddSaleScreen(
                    onBack = { nav.popBackStack() },
                    onSave = { d, l, n, k, p, r, pay ->
                        vm.add(d, l, n, k, p, r, pay)
                        nav.popBackStack()
                    }
                )
            }
            composable(Routes.REPORTS) { ReportsScreen(sales) }
            composable(Routes.SETTINGS) {
                SettingsScreen(onClear = vm::clearAll, onAbout = { nav.navigate(Routes.ABOUT) })
            }
            composable(Routes.ABOUT) { AboutScreen(onBack = { nav.popBackStack() }) }
        }
    }
}
