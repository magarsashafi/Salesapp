// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [Sale::class], version = 2, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun saleDao(): SaleDao
}
