// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager

import com.km.salesmanager.data.Sale
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Local unit tests for [Sale]'s derived fields. Runs on the JVM, no
 * Android framework or device/emulator required.
 */
class SaleCalculationsTest {

    @Test
    fun total_isKilosTimesPricePerKilo() {
        val sale = Sale(
            date = "2026-09-17",
            salesLocation = "Adama",
            customerName = "Test Customer",
            kilos = 10.0,
            pricePerKilo = 25.0,
            commissionRate = 3.0
        )
        assertEquals(250.0, sale.total, 0.001)
    }

    @Test
    fun commission_isTotalTimesRateOverHundred() {
        val sale = Sale(
            date = "2026-09-17",
            salesLocation = "Adama",
            customerName = "Test Customer",
            kilos = 10.0,
            pricePerKilo = 25.0,
            commissionRate = 5.0
        )
        // total = 250.0, commission = 250.0 * 5 / 100 = 12.5
        assertEquals(12.5, sale.commission, 0.001)
    }

    @Test
    fun commission_defaultsToThreePercentRate() {
        val sale = Sale(
            date = "2026-09-17",
            salesLocation = "Adama",
            customerName = "Test Customer",
            kilos = 4.0,
            pricePerKilo = 100.0
        )
        // total = 400.0, default rate 3% -> commission = 12.0
        assertEquals(12.0, sale.commission, 0.001)
    }
}
