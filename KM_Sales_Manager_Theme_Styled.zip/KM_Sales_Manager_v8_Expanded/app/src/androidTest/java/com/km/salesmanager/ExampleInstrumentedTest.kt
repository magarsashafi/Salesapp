// KM SALES MANAGER - Koodii barachuuf qophaa'e
// Faayilaan kun kutaa tokko qofa irratti xiyyeeffata.
// Commentoota keessa jiran dubbisuun hojii koodii hubachuuf ni gargaara.

package com.km.salesmanager

import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith

import org.junit.Assert.assertEquals

/**
 * Instrumented test, run on an Android device or emulator.
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
@RunWith(AndroidJUnit4::class)
class ExampleInstrumentedTest {
    @Test
    fun useAppContext() {
        // Context of the app under test.
        val appContext = InstrumentationRegistry.getInstrumentation().targetContext
        assertEquals("com.km.salesmanager", appContext.packageName)
    }
}
