# KM Sales Manager

Android Jetpack Compose app for replacing the sales-record workflow shown in the supplied reference and Excel workbook.

## Included
- Dashboard: total kilos, sales revenue, commission
- Add Sale: date, customer, kilos, price/kg, commission rate
- Sales list with search, date-range filter, A–Z name sorting, per-row print, and delete
- Reports, PDF report printing, and CSV sharing
- Settings with clear-all confirmation
- Offline Room database
- MVVM + Repository structure
- Afaan Oromoo-oriented labels

## Excel workbook mapping
The supplied workbook had sheets `gabaastu gutu` and `galmee`.
The `galmee` sheet contained fields corresponding to:
`date`, `maqaa`, `kiilo`, `gatii`, `Walii gala`, `commission`.
The summary sheet calculated total kilos, total sales and commission.

This Android version calculates totals directly instead of depending on spreadsheet formulas.

## Open in Android Studio
1. Extract this ZIP.
2. Open the `KM_Sales_Manager` folder in Android Studio.
3. Let Gradle sync.
4. Use JDK 17.
5. Run on an Android 7.0+ device/emulator.

## Formula
Total = kilos × price per kilo
Commission = total × commission rate / 100

## Package
`com.km.salesmanager`

## New features
- Date range filter using YYYY-MM-DD
- Sort sales by customer name A–Z
- Print button on every sales entry; Android print dialog can save as PDF or print
- Reports screen has PDF/Print report

## Sales fields added
- **Iddoo Gurgurtaa**: bakka gurgurtaan itti raawwatame.
- **Maqaa**: maqaa nama/maamila.
- **Kiilo (Baay'ina)**: quantity in kilograms.
- **Gatii / kiiloo**: price per kilogram.
- **Haala Kaffaltii**: `Kaffale` or `Salaafa`.
- Existing PDF/print now includes location and payment status.
- Existing date filter and A–Z name sorting remain available.

## Same-date kilo reconciliation
When multiple sales are entered on the same date, the app groups them by date and shows the **combined kilo quantity** for that day. The Sales screen also shows the combined kilos and total for the currently filtered records. This makes entries from the same day easy to reconcile.

## Reports: daily, weekly, monthly
The Reports screen now supports:
- **Guyyaa**: one selected day
- **Torban**: week containing the selected day
- **Ji'a**: month containing the selected day
For each period it shows total kilos, **Galii (total sales)**, **Kaffalame (paid)**, **Haftee/Salaafa (receivable)**, and commission. The selected period can also be printed/saved through the Android PDF print dialog.


## Design
UI Theme fi style fakkii reference irratti hundaa'e: blue header, white rounded cards, green Paid, red Balance/Debt.
