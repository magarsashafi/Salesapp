# KM Sales Manager v8 Expanded

Project gara kutaa adda addaatti qoodamee qindaa'e:
1. data/ - Room Entity, DAO, Database, Repository
2. viewmodel/ - hojii database fi state management
3. ui/ - navigation fi app shell
4. ui/components/ - cards fi UI components wal-irraa fayyadamu
5. ui/screens/ - Dashboard, Sales, Add Sale, Reports, Settings, About
6. ui/theme/ - Material 3 theme

## Amaloota ijoo
- Dashboard: kiiloo, galii, kaffalame, haftee
- Gurgurtaa haaraa galmeessuu
- Kaffale (cuquliisa) fi Salaafa/Haftee (diimaa) adda baasuu
- Search fi filter
- Gabaasa Guyyaa / Torban / Ji'a
- Maqaa namoota kaffalanii fi haftee qaban tarreessuu
- Commission shallaguu
- Room Database offline/persistent
- Settings keessatti data hunda qulqulleessuu
- UI file tokko guddaa keessa osoo hin taane screen/component/data layers keessatti qoodame

## Akka Android Studio keessatti banamu
KM_Sales_Manager_v8_Expanded folder filadhu -> Gradle Sync -> Run.
