# KM Sales Manager v7 – Resources

## Icons
Drawable vector icons are provided for dashboard, sales, reports, settings, add, search, print, calendar, location, person, paid, outstanding/debt, sort, filter, info, delete and save.

## Theme resources
- `values/colors.xml` – KM blue, red, green, background and text colors.
- `values/strings.xml` – Afaan Oromoo labels.
- `values/dimens.xml` – reusable spacing/radius values.
- `values/themes.xml` – Android theme.

## Launcher
Adaptive launcher icon resources are under `mipmap-anydpi-v26/`.

## Data/support resources
- `raw/sample_sales.csv` – sample import/reference data.
- `xml/backup_rules.xml` and `xml/data_extraction_rules.xml` – backup/transfer configuration.

The app continues to use Jetpack Compose Material Icons for its runtime UI, while these XML vectors provide a complete Android resource set for future XML screens, notifications, shortcuts and branding.
